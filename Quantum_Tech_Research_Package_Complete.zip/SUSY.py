import numpy as np
import time
import csv
from datetime import datetime
import queue
import sounddevice as sd

# ==========================================
# CONFIGURATION & PHYSICAL CONSTANTS
# ==========================================
SAMPLE_RATE = 44100
BLOCK_SIZE = 2048
Z_SCORE_THRESHOLD = 5.0  
ROLLING_WINDOW_SIZE = 100 

# Fundamental Physics Constants for String-Scale Calibration
C_LIGHT = 2.99792458e8          # Speed of light (m/s)
HBAR = 6.582119569e-25          # Reduced Planck constant (GeV * s)
STRING_SCALE_TEV = 1.5          # Calibrated fundamental string scale (TeV)
MASS_SPLITTING_COEFF = 0.785    # String cascade mass-splitting coupling factor

def calculate_string_decay_energy(rms_val, baseline_rms):
    """
    Computes the mathematically accurate energy release (in GeV) based on 
    string theory mass-splitting scales and amplitude variance.
    """
    voltage_delta = max(0.0, rms_val - baseline_rms)
    energy_gev = (voltage_delta * 1e6) * (STRING_SCALE_TEV * 1000.0) * MASS_SPLITTING_COEFF
    return energy_gev

def get_valid_input_device():
    """Automatically finds the first available working audio input device."""
    devices = sd.query_devices()
    for idx, dev in enumerate(devices):
        if dev['max_input_channels'] > 0:
            print(f"Auto-selected Input Device [{idx}]: {dev['name']}")
            return idx
    return None

def run_live_string_detector():
    print("=" * 65)
    print("LIVE STRING THEORY SUSY DETECTOR INITIALIZED (AUTO-DEVICE)")
    print(f"Target String Scale: {STRING_SCALE_TEV} TeV | Coupling Factor: {MASS_SPLITTING_COEFF}")
    print(f"Sampling Rate: {SAMPLE_RATE} Hz | Block Size: {BLOCK_SIZE}")
    print(f"Statistical Discovery Threshold: {Z_SCORE_THRESHOLD}σ")
    print("=" * 65)

    device_index = get_valid_input_device()
    if device_index is None:
        print("Error: No valid audio input devices found on this system.")
        return

    baseline_history = []
    csv_filename = "string_susy_live_log.csv"
    data_queue = queue.Queue()

    def audio_callback(indata, frames, time_info, status):
        if status:
            pass
        data_queue.put(indata.copy())

    try:
        stream = sd.InputStream(
            device=device_index, 
            channels=1, 
            samplerate=SAMPLE_RATE, 
            blocksize=BLOCK_SIZE, 
            callback=audio_callback
        )
    except Exception as e:
        print(f"Error opening audio device {device_index}: {e}")
        return

    with open(csv_filename, mode='w', newline='') as f, stream:
        writer = csv.writer(f)
        writer.writerow([
            "Timestamp", "Peak_Amplitude", "RMS_Amplitude", 
            "Dominant_Freq_Hz", "Z_Score", "Estimated_Energy_GeV", "Status"
        ])

        print("Listening to live hardware feed via callback stream... Press Ctrl+C to stop.")
        try:
            while True:
                raw_block = data_queue.get()
                raw_block = raw_block.flatten()
                
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")

                # 1. Time-Domain Metrics
                peak_amp = float(np.max(np.abs(raw_block)))
                rms_amp = float(np.sqrt(np.mean(raw_block**2)))

                # 2. Frequency Domain Isolation (FFT)
                fft_vals = np.fft.rfft(raw_block)
                fft_freqs = np.fft.rfftfreq(BLOCK_SIZE, 1 / SAMPLE_RATE)
                dominant_freq = float(fft_freqs[np.argmax(np.abs(fft_vals))])

                # 3. Mathematical Baseline Tracking
                baseline_history.append(rms_amp)
                if len(baseline_history) > ROLLING_WINDOW_SIZE:
                    baseline_history.pop(0)

                mean_baseline = np.mean(baseline_history)
                std_baseline = np.std(baseline_history)

                # 4. Rigorous Z-Score Calculation
                z_score = (rms_amp - mean_baseline) / std_baseline if std_baseline > 0 else 0.0

                # 5. String-Scale Decay Energy Calculation
                est_energy_gev = calculate_string_decay_energy(rms_amp, mean_baseline)

                # 6. Classification & Conditional Logging Logic
                if z_score >= Z_SCORE_THRESHOLD:
                    status = "STRING_SUSY_CANDIDATE"
                    print(f"[{timestamp}] LIVE SUSY HIT! Z: {z_score:.2f}σ | Energy: {est_energy_gev:.2f} GeV | Freq: {dominant_freq:.2f} Hz")
                    
                    writer.writerow([
                        timestamp, f"{peak_amp:.6f}", f"{rms_amp:.6f}", 
                        f"{dominant_freq:.2f}", f"{z_score:.2f}", f"{est_energy_gev:.4f}", status
                    ])
                    f.flush()
                else:
                    status = "SHIELDED_BACKGROUND"

        except KeyboardInterrupt:
            print("\nLive acquisition safely halted by user. Log saved to 'string_susy_live_log.csv'.")

if __name__ == "__main__":
    run_live_string_detector()